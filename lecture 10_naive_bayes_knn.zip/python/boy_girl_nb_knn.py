import numpy as np
import scipy.io as sio
from scipy.stats import norm
from sklearn.neighbors import NearestNeighbors
from show_image import show_image

# Load datasets
boys = sio.loadmat('new_boys.mat')
girls = sio.loadmat('new_girls.mat')

boys_data = boys['boyRaw'].astype(float)
girls_data = girls['girlRaw'].astype(float)

# Setting random seed for reproducibility
np.random.seed(1)

# Calculate training and testing sizes (80:20 split)
train_size_boys = round(0.8 * boys_data.shape[1])
train_size_girls = round(0.8 * girls_data.shape[1])

test_size_boys = boys_data.shape[1] - train_size_boys
test_size_girls = girls_data.shape[1] - train_size_girls

# Loop running the algorithms once on a random 80:20 split of the dataset
nb_accuracy = []
knn_accuracy = []

boys_indices = np.random.permutation(boys_data.shape[1])
girls_indices = np.random.permutation(girls_data.shape[1])

boys_train = boys_indices[:train_size_boys]
girls_train = girls_indices[:train_size_girls]

boys_test = boys_indices[train_size_boys:]
girls_test = girls_indices[train_size_girls:]

train_x = np.concatenate((boys_data[:, boys_train], girls_data[:, girls_train]), axis=1)
test_x = np.concatenate((boys_data[:, boys_test], girls_data[:, girls_test]), axis=1)
train_y = np.concatenate((np.zeros(train_size_boys), np.ones(train_size_girls)))
test_y = np.concatenate((np.zeros(test_size_boys), np.ones(test_size_girls)))

trainno = len(train_y)
dimno = train_x.shape[0]
testno = len(test_y)

# Naive Bayes
py = np.zeros(2)
mu_x_y = np.zeros((dimno, 2))
sigma_x_y = np.zeros((dimno, 2))
pytest = np.zeros((testno, 2))
predy = np.zeros(testno)
count_acc = 0

for i in range(2):
    py[i] = np.sum(train_y == i) / trainno

for i in range(dimno):
    mu_x_y[i, 0] = np.mean(train_x[i, :train_size_boys])
    mu_x_y[i, 1] = np.mean(train_x[i, train_size_boys:train_size_boys+train_size_girls])
    sigma_x_y[i, 0] = np.std(train_x[i, :train_size_boys])
    sigma_x_y[i, 1] = np.std(train_x[i, train_size_boys:train_size_boys+train_size_girls])

for i in range(testno):
    for k in range(2):
        pytest[i, k] = np.log10(py[k])
        for j in range(dimno):
            pytest[i, k] += np.log10(norm.pdf(test_x[j, i], mu_x_y[j, k], sigma_x_y[j, k] + 1e-3))
    predy[i] = np.argmax(pytest[i, :])
    if predy[i] == test_y[i]:
        count_acc += 1

nb_accuracy.append(count_acc / testno)

# K-Nearest Neighbors
K = 20
nbrs = NearestNeighbors(n_neighbors=K, algorithm='auto').fit(train_x.T)
distances, indices = nbrs.kneighbors(test_x.T)
predy_knn = np.zeros(testno)
img_class = np.zeros((2, dimno, testno))
count_acc_knn = 0

for i in range(testno):
    counts = np.zeros(2)
    for idx in indices[i]:
        counts[int(train_y[idx])] += 1
    index = np.argmax(counts)
    predy_knn[i] = index
    img_class[index, :, i] = test_x[:, i]
    if predy_knn[i] == test_y[i]:
        count_acc_knn += 1

knn_accuracy.append(count_acc_knn / testno)

class1 = img_class[0, :, :]
show_image(class1, 65, 65)

class2 = img_class[1, :, :]
show_image(class2, 65, 65)

print("Naive Bayes Accuracy:", nb_accuracy)
print("KNN Accuracy:", knn_accuracy)
