import numpy as np
from scipy.stats import norm
import scipy.io as sio
import matplotlib.pyplot as plt
from show_image import show_image

# Load dataset for boys and girls
boys_data = sio.loadmat('new_boys.mat')
girls_data = sio.loadmat('new_girls.mat')
# Convert data to double precision
boys_data = boys_data['boyRaw'].astype(float)
girls_data = girls_data['girlRaw'].astype(float)

# Training and testing sizes
train_size_boys = boys_data.shape[1]
train_size_girls = girls_data.shape[1]
test_size_boys = train_size_boys
test_size_girls = train_size_girls

# Seed the random number generator
np.random.seed(1)

# Iterate through random splits of data
for p in range(1):
    boys_indices = np.random.permutation(boys_data.shape[1])
    girls_indices = np.random.permutation(girls_data.shape[1])

    boys_train = boys_indices[:train_size_boys]
    girls_train = girls_indices[:train_size_girls]
    boys_test = boys_train
    girls_test = girls_train

    trainx = np.hstack((boys_data[:, boys_train], girls_data[:, girls_train]))
    testx = np.hstack((boys_data[:, boys_test], girls_data[:, girls_test]))
    trainy = np.concatenate((np.zeros(train_size_boys), np.ones(train_size_girls)))
    testy = np.concatenate((np.zeros(test_size_boys), np.ones(test_size_girls)))

    trainno = len(trainy)
    dimno = trainx.shape[0]
    testno = len(testy)

    # Show the image (assuming a function `show_image` is defined)
    show_image(testx, 65, 65)


    # Naive Bayes
    py = np.zeros(2)
    for i in range(2):
        py[i] = np.sum(trainy == i) / trainno

    mu_x_y = np.zeros((dimno, 2))
    sigma_x_y = np.zeros((dimno, 2))

    for i in range(dimno):
        mu_x_y[i, 0] = np.mean(trainx[i, :train_size_boys])
        mu_x_y[i, 1] = np.mean(trainx[i, train_size_boys:])
        sigma_x_y[i, 0] = np.std(trainx[i, :train_size_boys])
        sigma_x_y[i, 1] = np.std(trainx[i, train_size_boys:])

    pytest = np.zeros((testno, 2))
    predy = np.zeros(testno)
    img_class = np.zeros((2, dimno, testno))
    count_acc = 0

    for i in range(testno):
        for k in range(2):
            pytest[i, k] = np.log10(py[k])
            for j in range(dimno):
                pytest[i, k] += np.log10(norm.pdf(testx[j, i], mu_x_y[j, k], sigma_x_y[j, k] + 1e-3))
        
        maxm, index = pytest[i, :].max(), np.argmax(pytest[i, :])
        predy[i] = index

        if predy[i] == testy[i]:
            count_acc += 1

        img_class[index, :, i] = testx[:, i]
    
    class1 = img_class[0, :, :]
    show_image(class1, 65, 65)

    class2 = img_class[1, :, :]
    show_image(class2, 65, 65)

    nb_accuracy = count_acc / testno
    print(f'Naive Bayes Accuracy for split {p+1}: {nb_accuracy:.2f}')

    # Optionally display images grouped by predicted class
    # You would need to define or adapt a `show_image` function to work with NumPy arrays.
