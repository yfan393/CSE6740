import math
import numpy as np
import matplotlib.pyplot as plt

def show_image(centroids, H, W):
    N = centroids.shape[0] // (H * W)
    assert N == 3 or N == 1
    K = centroids.shape[1]
    COLS = round(math.sqrt(K))
    ROWS = math.ceil(K / COLS)
    COUNTS = COLS * ROWS
    images = np.ones((ROWS * H, COLS * W, N)) * 0
    for i in range(K):
        r = i // COLS
        c = i % COLS
        images[r * H:r * H + H, c * W:c * W + W, :] = centroids[:,i].reshape(H, W, N).swapaxes(0,1)
    plt.imshow(images.astype(np.uint8), cmap='gray')
    plt.show()
